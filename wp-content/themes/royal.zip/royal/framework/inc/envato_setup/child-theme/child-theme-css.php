/*
 Theme Name:   <?php echo $new_theme_title, "\n"; ?>
 Theme URI:    http://8theme.com/
 Description:  Royal Child Theme
 Author:       8theme
 Author URI:   http://8theme.com
 Template:     royal
 Version:      1.0
 Text Domain:  royal-child
*/