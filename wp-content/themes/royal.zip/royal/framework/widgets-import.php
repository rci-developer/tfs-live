<?php 

return array(
	'ecommerce' => array(
		'footer2' => array(
			'flush' => true,
			'create' => false,
			'widgets' => array(
				'etheme-static-block' => array(
					'block_id' => 15536
				),
			)
		),
	),
);