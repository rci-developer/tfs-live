<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

wc_get_template( 'archive-product.php' );