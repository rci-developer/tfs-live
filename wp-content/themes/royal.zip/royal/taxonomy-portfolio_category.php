<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once( 'portfolio.php' );